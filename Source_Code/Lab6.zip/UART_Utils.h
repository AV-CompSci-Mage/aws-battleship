#ifndef __UART_UTILS_H__
#define __UART_UTILS_H__

extern void UARTA1_Init(void(*pfnHandler)(void));



#endif // __UART_UTILS_H__